Version 1.0 - OCMOD version by Anas
Adds the ability to upload images to the review section.

If you want to contribute just send your modifications.
Your name/copyright will be added.

The script is free for personal/business use but not for any other purpose (modifications, sale, etc).